import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link, useLocation } from 'react-router-dom';
import { 
    Home, Users, Calendar, DollarSign, ShoppingCart, 
    Package, Settings, BarChart3, Shield, Church,
    ChevronDown, ChevronRight, FileText, Clock,
    BookOpen, TrendingUp, Archive
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

const Sidebar = ({ isOpen, onClose }) => {
    const location = useLocation();
    const { user, hasPermission } = useAuth();
    const [expandedMenus, setExpandedMenus] = useState({});

    const toggleMenu = (menuId) => {
        setExpandedMenus(prev => ({
            ...prev,
            [menuId]: !prev[menuId]
        }));
    };

    const menuItems = [
        {
            id: 'dashboard',
            title: 'Dashboard',
            icon: Home,
            path: '/dashboard',
            permission: 'dashboard'
        },
        {
            id: 'security',
            title: 'Seguridad',
            icon: Shield,
            permission: 'security',
            children: [
                { title: 'Usuarios', path: '/security/users', icon: Users },
                { title: 'Roles', path: '/security/roles', icon: Shield },
                { title: 'Permisos', path: '/security/permissions', icon: Settings }
            ]
        },
        {
            id: 'personal',
            title: 'Personal',
            icon: Users,
            path: '/personal',
            permission: 'personal'
        },
        {
            id: 'liturgical',
            title: 'Actos Litúrgicos',
            icon: Church,
            permission: 'liturgical',
            children: [
                { title: 'Gestionar Actos', path: '/liturgical/manage', icon: Church },
                { title: 'Horarios', path: '/liturgical/schedules', icon: Clock },
                { title: 'Reservas', path: '/liturgical/reservations', icon: Calendar },
                { title: 'Reportes', path: '/liturgical/reports', icon: FileText }
            ]
        },
        {
            id: 'accounting',
            title: 'Contabilidad',
            icon: DollarSign,
            path: '/accounting',
            permission: 'accounting'
        },
        {
            id: 'sales',
            title: 'Ventas',
            icon: TrendingUp,
            path: '/sales',
            permission: 'sales'
        },
        {
            id: 'purchases',
            title: 'Compras',
            icon: ShoppingCart,
            path: '/purchases',
            permission: 'purchases'
        },
        {
            id: 'warehouse',
            title: 'Almacén',
            icon: Package,
            path: '/warehouse',
            permission: 'warehouse'
        },
        {
            id: 'configuration',
            title: 'Configuración',
            icon: Settings,
            path: '/configuration',
            permission: 'configuration'
        },
        {
            id: 'reports',
            title: 'Reportes Generales',
            icon: BarChart3,
            permission: 'reports',
            children: [
                { title: 'Reportes Gerenciales', path: '/reports/management', icon: TrendingUp },
                { title: 'Reportes Transaccionales', path: '/reports/transactions', icon: Archive }
            ]
        }
    ];

    const filteredMenuItems = menuItems.filter(item => hasPermission(item.permission));

    const isActive = (path) => location.pathname === path;
    const isParentActive = (children) => children?.some(child => isActive(child.path));

    return (
        <AnimatePresence>
            {isOpen && (
                <>
                    <motion.div
                        className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        onClick={onClose}
                    />
                    <motion.div
                        className="fixed left-0 top-0 h-full w-80 bg-white shadow-2xl z-50 lg:relative lg:w-64 lg:shadow-none"
                        initial={{ x: -320 }}
                        animate={{ x: 0 }}
                        exit={{ x: -320 }}
                        transition={{ type: "spring", damping: 25, stiffness: 200 }}
                    >
                        <div className="flex flex-col h-full">
                            <div className="p-6 border-b border-gray-200">
                                <div className="flex items-center gap-3">
                                    <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl flex items-center justify-center">
                                        <Church className="w-6 h-6 text-white" />
                                    </div>
                                    <div>
                                        <h1 className="text-xl font-bold text-gray-900">SisParroquia</h1>
                                        <p className="text-sm text-gray-500">Sistema de Gestión</p>
                                    </div>
                                </div>
                            </div>

                            <div className="flex-1 overflow-y-auto py-4">
                                <nav className="px-4 space-y-2">
                                    {filteredMenuItems.map((item) => (
                                        <div key={item.id}>
                                            {item.children ? (
                                                <div>
                                                    <button
                                                        onClick={() => toggleMenu(item.id)}
                                                        className={`w-full flex items-center justify-between px-4 py-3 rounded-xl font-medium transition-all duration-200 ${
                                                            isParentActive(item.children)
                                                                ? 'bg-blue-50 text-blue-700 border border-blue-200'
                                                                : 'text-gray-700 hover:bg-gray-50'
                                                        }`}
                                                    >
                                                        <div className="flex items-center gap-3">
                                                            <item.icon className="w-5 h-5" />
                                                            <span>{item.title}</span>
                                                        </div>
                                                        {expandedMenus[item.id] ? (
                                                            <ChevronDown className="w-4 h-4" />
                                                        ) : (
                                                            <ChevronRight className="w-4 h-4" />
                                                        )}
                                                    </button>
                                                    <AnimatePresence>
                                                        {expandedMenus[item.id] && (
                                                            <motion.div
                                                                initial={{ height: 0, opacity: 0 }}
                                                                animate={{ height: 'auto', opacity: 1 }}
                                                                exit={{ height: 0, opacity: 0 }}
                                                                transition={{ duration: 0.2 }}
                                                                className="overflow-hidden"
                                                            >
                                                                <div className="ml-4 mt-2 space-y-1">
                                                                    {item.children.map((child) => (
                                                                        <Link
                                                                            key={child.path}
                                                                            to={child.path}
                                                                            onClick={onClose}
                                                                            className={`flex items-center gap-3 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                                                                                isActive(child.path)
                                                                                    ? 'bg-blue-100 text-blue-700 border-l-4 border-blue-500'
                                                                                    : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                                                                            }`}
                                                                        >
                                                                            <child.icon className="w-4 h-4" />
                                                                            <span>{child.title}</span>
                                                                        </Link>
                                                                    ))}
                                                                </div>
                                                            </motion.div>
                                                        )}
                                                    </AnimatePresence>
                                                </div>
                                            ) : (
                                                <Link
                                                    to={item.path}
                                                    onClick={onClose}
                                                    className={`flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all duration-200 ${
                                                        isActive(item.path)
                                                            ? 'bg-blue-50 text-blue-700 border border-blue-200'
                                                            : 'text-gray-700 hover:bg-gray-50'
                                                    }`}
                                                >
                                                    <item.icon className="w-5 h-5" />
                                                    <span>{item.title}</span>
                                                </Link>
                                            )}
                                        </div>
                                    ))}
                                </nav>
                            </div>

                            <div className="p-4 border-t border-gray-200">
                                <div className="flex items-center gap-3 px-4 py-3 bg-gray-50 rounded-xl">
                                    <div className="w-8 h-8 bg-gradient-to-br from-green-500 to-blue-500 rounded-full flex items-center justify-center">
                                        <span className="text-white text-sm font-bold">
                                            {user?.name?.charAt(0) || 'U'}
                                        </span>
                                    </div>
                                    <div className="flex-1 min-w-0">
                                        <p className="text-sm font-medium text-gray-900 truncate">
                                            {user?.name || 'Usuario'}
                                        </p>
                                        <p className="text-xs text-gray-500 capitalize">
                                            {user?.role || 'usuario'}
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </motion.div>
                </>
            )}
        </AnimatePresence>
    );
};

export default Sidebar;